package com.incertus.inisland

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

// IN-island — by incertus © 2026

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Prefs.enabled && Settings.canDrawOverlays(c)) {
            try { c.startForegroundService(Intent(c, IslandService::class.java)) } catch (_: Exception) {}
        }
    }
}
