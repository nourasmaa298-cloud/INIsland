package com.incertus.inisland

import android.app.PendingIntent
import android.app.Application
import android.content.Context
import android.graphics.drawable.Drawable

// IN-island — by incertus © 2026

enum class Kind { NOTIF, MEDIA, CHARGE, INFO }

data class IslandData(
    val kind: Kind,
    val title: String,
    val text: String = "",
    val icon: Drawable? = null,
    val emoji: String? = null,
    val pending: PendingIntent? = null,
    val playing: Boolean = false,
    val pkg: String? = null
)

/** جسر بين مستمع الإشعارات / الواجهة وخدمة الجزيرة */
object IslandBridge {
    @Volatile var onPost: ((IslandData) -> Unit)? = null
    @Volatile var onConfig: (() -> Unit)? = null
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

class InApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
    }
}
