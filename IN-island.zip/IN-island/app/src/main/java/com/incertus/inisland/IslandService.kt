package com.incertus.inisland

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.BitmapDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.FrameLayout

// IN-island — by incertus © 2026

class IslandService : Service() {

    private lateinit var wm: WindowManager
    private var root: FrameLayout? = null
    private var island: IslandView? = null
    private lateinit var lp: WindowManager.LayoutParams
    private val h = Handler(Looper.getMainLooper())

    private var transient: IslandData? = null
    private var media: IslandData? = null
    private var expanded = false
    private var touchable = false

    private var controller: MediaController? = null
    private var mediaStarted = false

    private val clearRunnable = Runnable {
        transient = null
        expanded = false
        refresh()
    }

    // ───────── دورة حياة الخدمة ─────────
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        goForeground()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        addOverlay()
        registerReceivers()
        if (Prefs.media) startMedia()
        IslandBridge.onPost = { d -> h.post { showTransient(d) } }
        IslandBridge.onConfig = { h.post { onConfigChanged() } }
        refresh()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        return START_STICKY
    }

    override fun onDestroy() {
        IslandBridge.onPost = null
        IslandBridge.onConfig = null
        h.removeCallbacksAndMessages(null)
        try { unregisterReceiver(rcv) } catch (_: Exception) {}
        stopMedia()
        try { root?.let { wm.removeView(it) } } catch (_: Exception) {}
        root = null; island = null
        super.onDestroy()
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("island", "IN-island", NotificationManager.IMPORTANCE_MIN))
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "island")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("IN-island يعمل")
            .setContentText("by incertus")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    // ───────── النافذة العائمة ─────────
    private fun addOverlay() {
        val r = FrameLayout(this)
        val v = IslandView(this)
        r.addView(v)
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(Prefs.topOffset)
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        v.onTap = { onIslandTap() }
        v.onSwipeUp = { collapse(); refresh() }
        v.onMedia = { a -> onMediaAction(a) }
        wm.addView(r, lp)
        root = r; island = v
    }

    private fun setTouchable(t: Boolean) {
        if (t == touchable) return
        touchable = t
        lp.flags = if (t) lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        else lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        try { root?.let { wm.updateViewLayout(it, lp) } } catch (_: Exception) {}
    }

    private fun onConfigChanged() {
        lp.y = dp(Prefs.topOffset)
        try { root?.let { wm.updateViewLayout(it, lp) } } catch (_: Exception) {}
        if (Prefs.media) { if (!mediaStarted) startMedia() } else stopMedia()
        island?.applyConfig()
        refresh()
    }

    // ───────── منطق العرض ─────────
    private fun refresh() {
        val v = island ?: return
        val d = transient ?: media
        if (d == null) expanded = false
        val mode = when {
            d == null -> IslandView.Mode.IDLE
            expanded -> IslandView.Mode.EXPANDED
            else -> IslandView.Mode.COMPACT
        }
        v.render(d, mode)
        setTouchable(d != null)
    }

    private fun scheduleClear(ms: Long) {
        h.removeCallbacks(clearRunnable)
        h.postDelayed(clearRunnable, ms)
    }

    private fun showTransient(d: IslandData) {
        transient = d
        expanded = false
        refresh()
        scheduleClear(Prefs.notifSec * 1000L)
    }

    private fun collapse() {
        expanded = false
        transient = null
        h.removeCallbacks(clearRunnable)
    }

    private fun onIslandTap() {
        val d = transient ?: media ?: return
        if (!expanded) {
            expanded = true
            scheduleClear(8000)
        } else {
            if (d.kind == Kind.NOTIF) openNotification(d)
            collapse()
        }
        refresh()
    }

    private fun openNotification(d: IslandData) {
        try {
            if (d.pending != null) d.pending.send()
            else d.pkg?.let { p -> packageManager.getLaunchIntentForPackage(p)?.let { startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
        } catch (_: Exception) {
            try {
                d.pkg?.let { p -> packageManager.getLaunchIntentForPackage(p)?.let { startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
            } catch (_: Exception) {}
        }
    }

    // ───────── الوسائط ─────────
    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { onSessions(it) }

    private val mcb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) { buildMedia() }
        override fun onMetadataChanged(metadata: MediaMetadata?) { buildMedia() }
        override fun onSessionDestroyed() { controller = null; buildMedia() }
    }

    private fun startMedia() {
        val msm = getSystemService(MediaSessionManager::class.java)
        val cn = ComponentName(this, IslandNotificationListener::class.java)
        try {
            msm.addOnActiveSessionsChangedListener(sessionsListener, cn)
            mediaStarted = true
            onSessions(msm.getActiveSessions(cn))
        } catch (_: SecurityException) {
            mediaStarted = false // لم يُمنح إذن قراءة الإشعارات بعد
        }
    }

    private fun stopMedia() {
        try { getSystemService(MediaSessionManager::class.java).removeOnActiveSessionsChangedListener(sessionsListener) } catch (_: Exception) {}
        controller?.unregisterCallback(mcb)
        controller = null
        media = null
        mediaStarted = false
    }

    private fun onSessions(list: List<MediaController>?) {
        val c = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull()
        if (c?.sessionToken != controller?.sessionToken) {
            controller?.unregisterCallback(mcb)
            controller = c
            c?.registerCallback(mcb)
        }
        buildMedia()
    }

    private fun buildMedia() {
        val c = controller
        val st = c?.playbackState?.state
        if (c == null || (st != PlaybackState.STATE_PLAYING && st != PlaybackState.STATE_PAUSED && st != PlaybackState.STATE_BUFFERING)) {
            media = null
        } else {
            val m = c.metadata
            val t = m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Unknown"
            val a = m?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
            val bmp = m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            media = IslandData(
                kind = Kind.MEDIA, title = t, text = a,
                icon = bmp?.let { BitmapDrawable(resources, it) },
                emoji = "🎵", playing = st == PlaybackState.STATE_PLAYING, pkg = c.packageName
            )
        }
        refresh()
    }

    private fun onMediaAction(a: String) {
        val c = controller ?: return
        val tc = c.transportControls
        when (a) {
            "prev" -> tc.skipToPrevious()
            "next" -> tc.skipToNext()
            else -> if (c.playbackState?.state == PlaybackState.STATE_PLAYING) tc.pause() else tc.play()
        }
        scheduleClear(8000)
    }

    // ───────── الشحن والبطارية ─────────
    private fun batteryLevel(): Int {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val l = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val s = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        return if (s > 0) l * 100 / s else l
    }

    private val rcv = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (!Prefs.charging) return
            when (i.action) {
                Intent.ACTION_POWER_CONNECTED ->
                    showTransient(IslandData(Kind.CHARGE, "جاري الشحن", "${batteryLevel()}%", emoji = "⚡"))
                Intent.ACTION_POWER_DISCONNECTED ->
                    showTransient(IslandData(Kind.INFO, "تم فصل الشاحن", "${batteryLevel()}%", emoji = "🔌"))
                Intent.ACTION_BATTERY_LOW ->
                    showTransient(IslandData(Kind.INFO, "البطارية منخفضة", "${batteryLevel()}%", emoji = "🪫"))
            }
        }
    }

    private fun registerReceivers() {
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_BATTERY_LOW)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(rcv, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(rcv, f)
    }
}
