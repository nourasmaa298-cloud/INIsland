package com.incertus.inisland

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

// IN-island — by incertus © 2026

class AppsActivity : Activity() {

    private data class A(val label: String, val pkg: String)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = 0xFF0B0B14.toInt()
        window.navigationBarColor = 0xFF0B0B14.toInt()
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { A(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
        val blocked = Prefs.blocked.toMutableSet()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0B0B14.toInt())
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(12), dp(40), dp(12), 0)
        }
        root.addView(TextView(this).apply {
            text = "التطبيقات المسموح لها بالظهور"
            textSize = 20f; setTextColor(0xFF00E5FF.toInt()); setPadding(dp(4), 0, 0, dp(4))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "ألغِ التحديد عن أي تطبيق لإخفاء إشعاراته من الجزيرة"
            textSize = 12f; setTextColor(0xFF9A9AB0.toInt()); setPadding(dp(4), 0, 0, dp(10))
        })

        val lv = ListView(this)
        val adapter = object : BaseAdapter() {
            override fun getCount() = apps.size
            override fun getItem(p: Int) = apps[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, cv: View?, parent: ViewGroup): View {
                val row: LinearLayout
                if (cv == null) {
                    row = LinearLayout(this@AppsActivity).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding(dp(6), dp(8), dp(6), dp(8))
                        addView(ImageView(context), LinearLayout.LayoutParams(dp(40), dp(40)))
                        addView(TextView(context).apply { textSize = 15f; setTextColor(Color.WHITE) },
                            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(12); marginEnd = dp(12) })
                        addView(CheckBox(context).apply { isClickable = false; isFocusable = false })
                    }
                } else row = cv as LinearLayout
                val a = apps[p]
                (row.getChildAt(0) as ImageView).setImageDrawable(try { pm.getApplicationIcon(a.pkg) } catch (_: Exception) { null })
                (row.getChildAt(1) as TextView).text = a.label
                (row.getChildAt(2) as CheckBox).isChecked = a.pkg !in blocked
                return row
            }
        }
        lv.adapter = adapter
        lv.divider = null
        lv.setOnItemClickListener { _, _, pos, _ ->
            val pkg = apps[pos].pkg
            if (pkg in blocked) blocked.remove(pkg) else blocked.add(pkg)
            Prefs.blocked = blocked
            adapter.notifyDataSetChanged()
        }
        root.addView(lv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }
}
