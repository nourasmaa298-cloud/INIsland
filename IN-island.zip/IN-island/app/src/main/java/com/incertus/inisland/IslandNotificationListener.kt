package com.incertus.inisland

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

// IN-island — by incertus © 2026

class IslandNotificationListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!Prefs.enabled || !Prefs.notifs) return
        val post = IslandBridge.onPost ?: return
        val n = sbn.notification ?: return
        val pkg = sbn.packageName
        if (pkg == packageName || pkg in Prefs.blocked) return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        if (n.category == Notification.CATEGORY_TRANSPORT) return
        val e = n.extras ?: return
        if (e.containsKey(Notification.EXTRA_MEDIA_SESSION)) return

        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Exception) { pkg }
        val title = e.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.takeIf { it.isNotBlank() } ?: label
        val text = (e.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: e.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
        val icon = try { packageManager.getApplicationIcon(pkg) } catch (_: Exception) { null }

        post(
            IslandData(
                kind = Kind.NOTIF, title = title, text = text, icon = icon,
                emoji = "🔔", pending = n.contentIntent, pkg = pkg
            )
        )
    }
}
