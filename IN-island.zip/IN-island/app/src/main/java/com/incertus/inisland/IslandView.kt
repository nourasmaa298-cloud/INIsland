package com.incertus.inisland

import android.animation.TimeInterpolator
import android.animation.ValueAnimator
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

// IN-island — by incertus © 2026

/** موجات صوت متحركة */
class WaveView(ctx: Context) : View(ctx) {
    var color: Int = Color.WHITE
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private var anim: ValueAnimator? = null
    private var active = false

    fun setActive(a: Boolean) { active = a; update() }

    private fun update() {
        if (active && isAttachedToWindow) {
            if (anim == null) {
                anim = ValueAnimator.ofFloat(0f, (2 * PI).toFloat()).apply {
                    duration = 900
                    repeatCount = ValueAnimator.INFINITE
                    interpolator = LinearInterpolator()
                    addUpdateListener { phase = it.animatedValue as Float; invalidate() }
                    start()
                }
            }
        } else {
            anim?.cancel(); anim = null; invalidate()
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); update() }
    override fun onDetachedFromWindow() { anim?.cancel(); anim = null; super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        p.color = color
        val bars = 4
        val bw = width / (bars * 2 - 1f)
        for (i in 0 until bars) {
            val f = if (active) 0.3f + 0.7f * abs(sin(phase + i * 0.9f)) else 0.3f
            val h = height * f
            val l = i * bw * 2
            val r = RectF(l, (height - h) / 2f, l + bw, (height + h) / 2f)
            c.drawRoundRect(r, bw / 2f, bw / 2f, p)
        }
    }
}

/** الجزيرة نفسها: تتحرك بين ثلاث حالات (خاملة / مصغّرة / موسّعة) */
class IslandView(ctx: Context) : FrameLayout(ctx) {
    enum class Mode { IDLE, COMPACT, EXPANDED }

    var onTap: (() -> Unit)? = null
    var onSwipeUp: (() -> Unit)? = null
    var onMedia: ((String) -> Unit)? = null
    var maxW: Int = 0

    private var curW = 0f
    private var curH = 0f
    private var curR = 0f
    private var animator: ValueAnimator? = null
    private var glowAnim: ValueAnimator? = null
    private var glowAlpha = 120
    private var mode = Mode.IDLE
    private var lastKey: String? = null
    private var lastData: IslandData? = null

    private val bg = GradientDrawable()
    private val iconBox = FrameLayout(ctx)
    private val iconView = ImageView(ctx)
    private val emojiView = TextView(ctx)
    private val title = TextView(ctx)
    private val text = TextView(ctx)
    private val wave = WaveView(ctx)
    private val row = LinearLayout(ctx)
    private val controls = LinearLayout(ctx)
    private val content = LinearLayout(ctx)
    private val btnPrev = ctrl("⏮", "prev")
    private val btnPlay = ctrl("⏯", "toggle")
    private val btnNext = ctrl("⏭", "next")

    private val gd = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onSingleTapUp(e: MotionEvent): Boolean { onTap?.invoke(); return true }
        override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
            if (vy < -400f) { onSwipeUp?.invoke(); return true }
            return false
        }
    })

    private fun dp(v: Int): Int = context.dp(v)

    private fun ctrl(sym: String, action: String) = TextView(context).apply {
        this.text = sym
        textSize = 24f
        gravity = Gravity.CENTER
        setPadding(dp(18), dp(4), dp(18), dp(4))
        setOnClickListener { onMedia?.invoke(action) }
    }

    init {
        layoutDirection = LAYOUT_DIRECTION_LTR
        background = bg
        clipToOutline = true
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, curR)
            }
        }

        iconView.scaleType = ImageView.ScaleType.CENTER_CROP
        iconBox.addView(iconView, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        emojiView.gravity = Gravity.CENTER
        iconBox.addView(emojiView, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        iconBox.clipToOutline = true

        title.maxLines = 1
        title.ellipsize = android.text.TextUtils.TruncateAt.END
        title.typeface = android.graphics.Typeface.DEFAULT_BOLD
        text.maxLines = 2
        text.ellipsize = android.text.TextUtils.TruncateAt.END
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            addView(title)
            addView(text)
        }

        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(iconBox, LinearLayout.LayoutParams(dp(22), dp(22)))
        row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(wave, LinearLayout.LayoutParams(dp(22), dp(18)).apply { marginStart = dp(8) })

        controls.orientation = LinearLayout.HORIZONTAL
        controls.gravity = Gravity.CENTER
        controls.visibility = GONE
        controls.addView(btnPrev); controls.addView(btnPlay); controls.addView(btnNext)

        content.orientation = LinearLayout.VERTICAL
        content.gravity = Gravity.CENTER_VERTICAL
        content.setPadding(dp(14), dp(6), dp(14), dp(6))
        content.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        content.addView(controls, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
        content.alpha = 0f
        addView(content, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))

        val t = target(Mode.IDLE, null)
        curW = t[0]; curH = t[1]; curR = t[2]
        applyColors()
        applySize()
        alpha = if (Prefs.idleShow) 1f else 0f
    }

    // ───────── الأحجام ─────────
    private fun target(m: Mode, d: IslandData?): FloatArray {
        val screenMax = if (maxW > 0) maxW.toFloat() else (resources.displayMetrics.widthPixels - dp(16)).toFloat()
        return when (m) {
            Mode.IDLE -> {
                val h = dp(Prefs.idleH).toFloat()
                floatArrayOf(min(dp(Prefs.idleW).toFloat(), screenMax), h, h / 2f)
            }
            Mode.COMPACT -> {
                val h = (dp(Prefs.idleH) + dp(6)).toFloat()
                floatArrayOf(min(dp(Prefs.compactW).toFloat(), screenMax), h, h / 2f)
            }
            Mode.EXPANDED -> {
                val hp = if (d?.kind == Kind.MEDIA) Prefs.expH else max(96, Prefs.expH - 40)
                val h = dp(hp).toFloat()
                floatArrayOf(min(dp(Prefs.expW).toFloat(), screenMax), h, min(dp(Prefs.expRadius).toFloat(), h / 2f))
            }
        }
    }

    private fun applySize() {
        val lp = (layoutParams as? LayoutParams)
            ?: LayoutParams(1, 1, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        lp.width = max(1, curW.toInt())
        lp.height = max(1, curH.toInt())
        layoutParams = lp
        bg.cornerRadius = max(0f, min(curR, min(curW, curH) / 2f))
        invalidateOutline()
    }

    private fun interp(): TimeInterpolator = when (Prefs.animStyle) {
        0 -> PathInterpolator(0.2f, 0f, 0f, 1f)
        1 -> OvershootInterpolator(2.4f)
        else -> TimeInterpolator { t ->
            if (t == 0f || t == 1f) t
            else (2.0.pow(-10.0 * t) * sin((t - 0.075) * (2 * PI) / 0.3) + 1).toFloat()
        }
    }

    private fun animateTo(w: Float, h: Float, r: Float) {
        animator?.cancel()
        val sw = curW; val sh = curH; val sr = curR
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = Prefs.animMs.toLong()
            interpolator = interp()
            addUpdateListener {
                val t = it.animatedValue as Float
                curW = sw + (w - sw) * t
                curH = sh + (h - sh) * t
                curR = sr + (r - sr) * t
                applySize()
            }
            start()
        }
    }

    // ───────── الألوان والتوهج ─────────
    private fun glowColor(): Int = (Prefs.accent and 0x00FFFFFF) or (glowAlpha shl 24)

    private fun applyColors() {
        bg.setColor(Prefs.bgColor)
        if (Prefs.glow) bg.setStroke(dp(2), glowColor()) else bg.setStroke(0, 0)
        title.setTextColor(Prefs.textColor)
        text.setTextColor((Prefs.textColor and 0x00FFFFFF) or (0xB3 shl 24))
        wave.color = Prefs.accent
        for (b in listOf(btnPrev, btnPlay, btnNext)) b.setTextColor(Prefs.accent)
        wave.invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        glowAnim = ValueAnimator.ofInt(50, 230).apply {
            duration = 1700
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                glowAlpha = it.animatedValue as Int
                if (Prefs.glow) bg.setStroke(dp(2), glowColor())
            }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        glowAnim?.cancel(); glowAnim = null
        animator?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean = gd.onTouchEvent(e) || super.onTouchEvent(e)

    // ───────── المحتوى ─────────
    private fun bind(d: IslandData, m: Mode) {
        val exp = m == Mode.EXPANDED
        val isz = dp(if (exp) 44 else 22)
        iconBox.layoutParams = LinearLayout.LayoutParams(isz, isz).apply { marginEnd = dp(10) }
        iconBox.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, view.width / 4f)
            }
        }
        if (d.icon != null) {
            iconView.setImageDrawable(d.icon)
            iconView.visibility = VISIBLE
            emojiView.visibility = GONE
        } else {
            iconView.visibility = GONE
            emojiView.visibility = VISIBLE
            emojiView.text = d.emoji ?: "✨"
            emojiView.textSize = if (exp) 26f else 14f
        }
        title.text = d.title
        title.textSize = if (exp) 15f else 13f
        text.text = d.text
        text.textSize = 13f
        text.visibility = if (exp && d.text.isNotEmpty()) VISIBLE else GONE
        val showWave = Prefs.wave && d.kind == Kind.MEDIA
        wave.visibility = if (showWave) VISIBLE else GONE
        wave.setActive(showWave && d.playing)
        controls.visibility = if (exp && d.kind == Kind.MEDIA) VISIBLE else GONE
        btnPlay.text = if (d.playing) "⏸" else "▶"
        content.setPadding(dp(14), dp(if (exp) 12 else 6), dp(14), dp(if (exp) 10 else 6))
    }

    fun applyConfig() {
        applyColors()
        render(lastData, mode)
    }

    fun render(d: IslandData?, m: Mode) {
        val key = d?.let { "${it.kind}|${it.title}|${it.text}" }
        val changed = key != lastKey
        val modeChanged = m != mode
        lastKey = key; mode = m; lastData = d
        applyColors()
        val t = target(m, d)
        animateTo(t[0], t[1], t[2])
        val dur = Prefs.animMs

        if (m == Mode.IDLE || d == null) {
            content.animate().cancel()
            content.animate().setStartDelay(0).setInterpolator(AccelerateDecelerateInterpolator())
                .alpha(0f).setDuration(120).start()
            wave.setActive(false)
            animate().cancel()
            animate().setStartDelay(0).setInterpolator(AccelerateDecelerateInterpolator())
                .alpha(if (Prefs.idleShow) 1f else 0f).setDuration(250).start()
        } else {
            animate().cancel()
            alpha = 1f
            bind(d, m)
            if (modeChanged || changed) {
                content.animate().cancel()
                content.alpha = 0f
                content.animate().setInterpolator(AccelerateDecelerateInterpolator())
                    .setStartDelay((dur * 0.3).toLong())
                    .setDuration((dur * 0.45).toLong())
                    .alpha(1f).start()
            }
            if (!modeChanged && changed && m == Mode.COMPACT) pulse()
        }
    }

    private fun pulse() {
        animate().cancel()
        scaleX = 1f; scaleY = 1f
        animate().setStartDelay(0).setInterpolator(AccelerateDecelerateInterpolator())
            .scaleX(1.08f).scaleY(1.08f).setDuration(120).withEndAction {
                animate().setStartDelay(0).setInterpolator(OvershootInterpolator(3f))
                    .scaleX(1f).scaleY(1f).setDuration(320).start()
            }.start()
    }
}
