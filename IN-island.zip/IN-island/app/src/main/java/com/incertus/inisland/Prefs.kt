package com.incertus.inisland

import android.content.Context
import android.content.SharedPreferences
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

// IN-island — by incertus © 2026
object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(c: Context) {
        sp = c.applicationContext.getSharedPreferences("in_island", Context.MODE_PRIVATE)
    }

    private class I(val k: String, val d: Int) : ReadWriteProperty<Any?, Int> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = sp.getInt(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) {
            sp.edit().putInt(k, value).apply()
        }
    }

    private class B(val k: String, val d: Boolean) : ReadWriteProperty<Any?, Boolean> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = sp.getBoolean(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) {
            sp.edit().putBoolean(k, value).apply()
        }
    }

    // التشغيل والميزات
    var enabled by B("enabled", false)
    var notifs by B("notifs", true)
    var media by B("media", true)
    var charging by B("charging", true)
    var idleShow by B("idleShow", true)
    var glow by B("glow", true)
    var wave by B("wave", true)

    // الأحجام (dp)
    var idleW by I("idleW", 112)
    var idleH by I("idleH", 34)
    var compactW by I("compactW", 200)
    var expW by I("expW", 330)
    var expH by I("expH", 150)
    var expRadius by I("expRadius", 32)
    var topOffset by I("topOffset", 10)

    // الحركة
    var animMs by I("animMs", 520)
    var animStyle by I("animStyle", 1) // 0 سلس، 1 ارتداد، 2 مرن
    var notifSec by I("notifSec", 5)

    // الألوان
    var bgColor by I("bg", 0xFF000000.toInt())
    var accent by I("accent", 0xFF00E5FF.toInt())
    var textColor by I("text", 0xFFFFFFFF.toInt())

    var blocked: Set<String>
        get() = sp.getStringSet("blocked", emptySet())!!.toSet()
        set(v) { sp.edit().putStringSet("blocked", HashSet(v)).apply() }
}
