package com.incertus.inisland

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

// IN-island — by incertus © 2026

class MainActivity : Activity() {

    private val BG = 0xFF0B0B14.toInt()
    private val CARD = 0xFF161622.toInt()
    private val TXT = 0xFFEDEDF5.toInt()
    private val SUB = 0xFF9A9AB0.toInt()
    private val ACC = 0xFF00E5FF.toInt()
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var preview: IslandView
    private lateinit var previewBox: FrameLayout
    private lateinit var stOverlay: TextView
    private lateinit var stListener: TextView
    private val h = Handler(Looper.getMainLooper())
    private var pData: IslandData? = null
    private var pExp = false
    private val pClear = Runnable { pData = null; pExp = false; pRender() }

    // ───────── دورة الحياة ─────────
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        val scroll = ScrollView(this).apply {
            setBackgroundColor(BG)
            isVerticalScrollBarEnabled = false
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(40), dp(12), dp(32))
        }
        scroll.addView(col)
        setContentView(scroll)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        // الترويسة
        col.addView(TextView(this).apply {
            text = "IN-island"
            textSize = 34f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(2))
            paint.shader = LinearGradient(0f, 0f, dpf(190f), 0f,
                intArrayOf(0xFF00E5FF.toInt(), 0xFFFF4D8D.toInt()), null, Shader.TileMode.CLAMP)
        })
        col.addView(label("جزيرة ديناميكية لهاتفك • by incertus", 13f, SUB).apply { gravity = Gravity.CENTER })

        // المعاينة الحيّة
        previewBox = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF3A1C71.toInt(), 0xFF1B1B3A.toInt(), 0xFF0F2027.toInt())).apply { cornerRadius = dpf(24f) }
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(210)).apply { topMargin = dp(14) }
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        preview = IslandView(this)
        previewBox.addView(preview)
        (preview.layoutParams as FrameLayout.LayoutParams).topMargin = dp(14)
        previewBox.post { preview.maxW = previewBox.width - dp(10); preview.applyConfig() }
        preview.onTap = { if (pData != null) { pExp = !pExp; pRender() } }
        preview.onSwipeUp = { pExp = false; pRender() }
        preview.onMedia = { }
        previewBox.addView(TextView(this).apply {
            text = "اضغط على الجزيرة لتوسيعها • اسحب للأعلى لإغلاقها"
            setTextColor(0x99FFFFFF.toInt()); textSize = 11f; gravity = Gravity.CENTER
        }, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM).apply { bottomMargin = dp(10) })
        col.addView(previewBox)

        // أزرار التجربة
        val demos = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) }
        }
        demos.addView(btn("🔔 إشعار") { demo(IslandData(Kind.NOTIF, "رسالة جديدة", "أهلاً بك في IN-island 👋 جزيرة بحركات سلسة", emoji = "💬")) }, weightLp())
        demos.addView(btn("⚡ شحن") { demo(IslandData(Kind.CHARGE, "جاري الشحن", "85%", emoji = "⚡")) }, weightLp())
        demos.addView(btn("🎵 موسيقى") { demo(IslandData(Kind.MEDIA, "Midnight City", "incertus", emoji = "🎵", playing = true)) }, weightLp())
        col.addView(demos)

        // التشغيل والأذونات
        val power = card()
        power.addView(Switch(this).apply {
            text = "تشغيل IN-island"
            textSize = 17f
            setTextColor(TXT)
            isChecked = Prefs.enabled && Settings.canDrawOverlays(context)
            setOnCheckedChangeListener { v, on ->
                if (on) {
                    if (!Settings.canDrawOverlays(context)) {
                        v.isChecked = false
                        toast("امنح إذن العرض فوق التطبيقات أولاً")
                        openOverlaySettings()
                        return@setOnCheckedChangeListener
                    }
                    Prefs.enabled = true
                    startForegroundService(Intent(context, IslandService::class.java))
                } else {
                    Prefs.enabled = false
                    stopService(Intent(context, IslandService::class.java))
                }
            }
        })
        stOverlay = label("", 13f, SUB).apply { setPadding(0, dp(10), 0, 0) }
        power.addView(stOverlay)
        power.addView(btn("منح إذن العرض فوق التطبيقات") { openOverlaySettings() })
        stListener = label("", 13f, SUB).apply { setPadding(0, dp(10), 0, 0) }
        power.addView(stListener)
        power.addView(btn("منح إذن قراءة الإشعارات") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        col.addView(power)

        // الميزات
        val feat = card()
        feat.addView(label("الميزات", 16f, ACC, true))
        feat.addView(switchRow("عرض الإشعارات", { Prefs.notifs }) { Prefs.notifs = it })
        feat.addView(switchRow("عرض الموسيقى والتحكم بها", { Prefs.media }) { Prefs.media = it })
        feat.addView(switchRow("تنبيهات الشحن والبطارية", { Prefs.charging }) { Prefs.charging = it })
        feat.addView(switchRow("إظهار الجزيرة وهي خاملة", { Prefs.idleShow }) { Prefs.idleShow = it })
        feat.addView(switchRow("توهّج الحدود المتحرك", { Prefs.glow }) { Prefs.glow = it })
        feat.addView(switchRow("موجات الصوت", { Prefs.wave }) { Prefs.wave = it })
        feat.addView(btn("التطبيقات المسموح لها بالظهور") { startActivity(Intent(this, AppsActivity::class.java)) })
        col.addView(feat)

        // الأحجام
        val size = card()
        size.addView(label("الأبعاد والموضع", 16f, ACC, true))
        size.addView(slider("عرض الجزيرة الخاملة", 60, 200, "dp", { Prefs.idleW }) { Prefs.idleW = it })
        size.addView(slider("ارتفاع الجزيرة", 20, 60, "dp", { Prefs.idleH }) { Prefs.idleH = it })
        size.addView(slider("عرض الوضع المصغّر", 120, 320, "dp", { Prefs.compactW }) { Prefs.compactW = it })
        size.addView(slider("عرض الوضع الموسّع", 240, 420, "dp", { Prefs.expW }) { Prefs.expW = it })
        size.addView(slider("ارتفاع الوضع الموسّع", 110, 240, "dp", { Prefs.expH }) { Prefs.expH = it })
        size.addView(slider("استدارة الزوايا", 12, 60, "dp", { Prefs.expRadius }) { Prefs.expRadius = it })
        size.addView(slider("المسافة من أعلى الشاشة", 0, 120, "dp", { Prefs.topOffset }) { Prefs.topOffset = it })
        col.addView(size)

        // الحركة
        val anim = card()
        anim.addView(label("الرسوم المتحركة", 16f, ACC, true))
        anim.addView(label("نمط الحركة", 13f, SUB).apply { setPadding(0, dp(8), 0, dp(4)) })
        val rg = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        listOf("سلس", "ارتداد", "مرن").forEachIndexed { i, n ->
            rg.addView(RadioButton(this).apply {
                id = 100 + i; text = n; setTextColor(TXT)
                buttonTintList = ColorStateList.valueOf(ACC)
                setPadding(dp(4), 0, dp(14), 0)
            })
        }
        rg.check(100 + Prefs.animStyle)
        rg.setOnCheckedChangeListener { _, id -> Prefs.animStyle = id - 100; changed(); demoQuick() }
        anim.addView(rg)
        anim.addView(slider("مدة الحركة", 150, 1200, "ms", { Prefs.animMs }) { Prefs.animMs = it })
        anim.addView(slider("مدة ظهور الإشعار", 2, 12, "ث", { Prefs.notifSec }) { Prefs.notifSec = it })
        col.addView(anim)

        // الألوان
        val colors = card()
        colors.addView(label("الألوان", 16f, ACC, true))
        colors.addView(colorRow("لون الخلفية",
            intArrayOf(0xFF000000.toInt(), 0xFF0A1128.toInt(), 0xFF1B0A3A.toInt(), 0xFF06241A.toInt(), 0xFF2A0610.toInt(), 0xFF1C1C1E.toInt()),
            { Prefs.bgColor }) { Prefs.bgColor = it })
        colors.addView(colorRow("اللون المميّز (التوهج والأزرار)",
            intArrayOf(0xFF00E5FF.toInt(), 0xFFFF4D8D.toInt(), 0xFFB6FF3B.toInt(), 0xFFFF9F1C.toInt(), 0xFFA78BFA.toInt(), 0xFFFFFFFF.toInt()),
            { Prefs.accent }) { Prefs.accent = it })
        colors.addView(colorRow("لون النص",
            intArrayOf(0xFFFFFFFF.toInt(), 0xFFD0D0E0.toInt(), 0xFFFFE066.toInt(), 0xFF9CFFD6.toInt()),
            { Prefs.textColor }) { Prefs.textColor = it })
        col.addView(colors)

        // الحقوق
        val foot = card()
        foot.addView(label("IN-island  v1.0.0", 15f, TXT, true).apply { gravity = Gravity.CENTER })
        foot.addView(label("صُنع بواسطة incertus", 14f, ACC, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) })
        foot.addView(label("© 2026 incertus — جميع الحقوق محفوظة", 12f, SUB).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) })
        col.addView(foot)

        // حركة دخول متتالية للبطاقات
        for (i in 0 until col.childCount) {
            val v = col.getChildAt(i)
            v.alpha = 0f
            v.translationY = dpf(40f)
            v.animate().alpha(1f).translationY(0f).setStartDelay(i * 70L).setDuration(450).start()
        }
    }

    override fun onResume() {
        super.onResume()
        val ov = Settings.canDrawOverlays(this)
        val ls = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")?.contains(packageName) == true
        stOverlay.text = if (ov) "✅ إذن العرض فوق التطبيقات: ممنوح" else "❌ إذن العرض فوق التطبيقات: غير ممنوح"
        stListener.text = if (ls) "✅ إذن قراءة الإشعارات: ممنوح" else "❌ إذن قراءة الإشعارات: غير ممنوح"
        if (Prefs.enabled && ov) startForegroundService(Intent(this, IslandService::class.java))
    }

    override fun onDestroy() { h.removeCallbacksAndMessages(null); super.onDestroy() }

    // ───────── المعاينة ─────────
    private fun pRender() {
        val m = when {
            pData == null -> IslandView.Mode.IDLE
            pExp -> IslandView.Mode.EXPANDED
            else -> IslandView.Mode.COMPACT
        }
        preview.render(pData, m)
    }

    private fun demo(d: IslandData) {
        pData = d; pExp = false; pRender()
        h.removeCallbacks(pClear); h.postDelayed(pClear, 5000)
        IslandBridge.onPost?.invoke(d)
    }

    private fun demoQuick() {
        pData = IslandData(Kind.NOTIF, "تجربة الحركة", "هكذا ستبدو الحركة الجديدة ✨", emoji = "✨")
        pExp = true; pRender()
        h.removeCallbacks(pClear); h.postDelayed(pClear, 2500)
    }

    private fun changed() {
        preview.applyConfig()
        pRender()
        IslandBridge.onConfig?.invoke()
    }

    private fun openOverlaySettings() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    // ───────── مكوّنات الواجهة ─────────
    private fun weightLp() = LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(3); marginEnd = dp(3) }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = GradientDrawable().apply { setColor(CARD); cornerRadius = dpf(20f) }
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) }
    }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t; setTextColor(Color.BLACK); isAllCaps = false; textSize = 13f
        background = GradientDrawable().apply { setColor(ACC); cornerRadius = dpf(14f) }
        layoutParams = LinearLayout.LayoutParams(MATCH, dp(46)).apply { topMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    private fun switchRow(t: String, get: () -> Boolean, set: (Boolean) -> Unit) = Switch(this).apply {
        text = t; textSize = 14f; setTextColor(TXT)
        setPadding(0, dp(8), 0, dp(8))
        isChecked = get()
        setOnCheckedChangeListener { _, c -> set(c); changed() }
    }

    private fun slider(title: String, lo: Int, hi: Int, unit: String, get: () -> Int, set: (Int) -> Unit): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, 0) }
        val lbl = label("", 13f, SUB)
        fun upd(v: Int) { lbl.text = "$title: $v $unit" }
        upd(get())
        val sb = SeekBar(this).apply {
            max = hi - lo
            progress = get() - lo
            progressTintList = ColorStateList.valueOf(ACC)
            thumbTintList = ColorStateList.valueOf(ACC)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = lo + p
                    upd(v)
                    if (fromUser) { set(v); changed() }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        box.addView(lbl); box.addView(sb)
        return box
    }

    private fun swatch(color: Int, selected: Boolean, onClick: () -> Unit) = TextView(this).apply {
        gravity = Gravity.CENTER
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
            setStroke(dp(if (selected) 3 else 1), if (selected) Color.WHITE else 0x44FFFFFF)
        }
        layoutParams = LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginEnd = dp(10) }
        setOnClickListener { onClick() }
    }

    private fun colorRow(title: String, presets: IntArray, get: () -> Int, set: (Int) -> Unit): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, 0) }
        box.addView(label(title, 13f, SUB).apply { setPadding(0, 0, 0, dp(6)) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        box.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) })
        fun rebuild() {
            row.removeAllViews()
            for (c in presets) row.addView(swatch(c, c == get()) { set(c); changed(); rebuild() })
            val custom = get() !in presets
            row.addView(swatch(if (custom) get() else 0xFF2A2A3A.toInt(), custom) {
                val et = EditText(this).apply {
                    setText(String.format("#%06X", get() and 0xFFFFFF))
                    setTextColor(Color.BLACK)
                }
                AlertDialog.Builder(this)
                    .setTitle("لون مخصص (HEX)")
                    .setView(et)
                    .setPositiveButton("تطبيق") { _, _ ->
                        try {
                            set(Color.parseColor(et.text.toString().trim()) or 0xFF000000.toInt())
                            changed(); rebuild()
                        } catch (_: Exception) { toast("صيغة اللون غير صحيحة، مثال: #FF8800") }
                    }
                    .setNegativeButton("إلغاء", null)
                    .show()
            }.also { (it as TextView).text = "✎"; it.setTextColor(Color.WHITE) })
        }
        rebuild()
        return box
    }
}
